from vadafok_studio.app import main

if __name__ == '__main__':
    main()
